/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalproject;

/**
 *
 * @author madhu
 */
import com.mycompany.finalproject.Event;
import java.sql.Connection;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
public class EventDAO {

   private static final String URL = "jdbc:mysql://localhost:3306/mydb";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "root";
    public static boolean insertEvent(Event p) {
        boolean status = false;
        Connection con = null;
        PreparedStatement ps = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            
            String query = "INSERT INTO info (planningfor, guest, type, days, inclusion, Mealtype, date, booked) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            ps = con.prepareStatement(query);
            ps.setString(1, p.getplanningfor());
            ps.setString(2, p.getguest());
            ps.setString(3, p.gettype());
            ps.setString(4, p.getdays());
            ps.setString(5, p.getinclusion());
            ps.setString(6, p.getMealtype());
            ps.setString(7, p.getdate());
            ps.setString(8, p.getbooked());
           
            int rowsInserted = ps.executeUpdate();
            status = rowsInserted > 0;

        } catch (SQLException e) {
            System.out.println("Database Error: " + e.getMessage()); // Print error to console
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            System.out.println("JDBC Driver Not Found: " + e.getMessage());
        } finally {
            try {
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return status;
    }
   
    
}