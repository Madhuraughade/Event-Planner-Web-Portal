/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalproject;

/**
 *
 * @author madhu
 */
public class Event {

    private String planningfor;
    private String guest;
    private String type;
    private String days;
    private String inclusion;
    private String Mealtype;
    private String date;
    private String booked;
    
    

    public Event(String planningfor, String guest, String type, String days, String inclusion,String Mealtype,String date,String booked) {
        this.planningfor = planningfor;
        this.guest = guest;
        this.type = type;
        this.days= days;
        this.inclusion = inclusion;
        this.Mealtype = Mealtype;
        this.date = date;
        this.booked = booked;
    }

   

    public String getplanningfor() { return planningfor; }
    public String getguest() { return guest; }
    public String gettype() { return type; }
    public String getdays() { return days; }
    public String getinclusion() { return inclusion; }
    public String getMealtype() { return Mealtype; }
    public String getdate() { return date; }
    public String getbooked() { return booked; }
    

   
}