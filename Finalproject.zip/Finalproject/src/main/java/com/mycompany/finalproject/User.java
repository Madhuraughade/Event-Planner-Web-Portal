/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalproject;

/**
 *
 * @author madhu
 */
public class User {

     private String username;
    private String password;
    private String contact;
    private String address;
    private String email;
    

    public User(String username, String password, String contact, String address, String email) {
        this.username = username;
        this.password = password;
        this.contact = contact;
        this.address= address;
        this.email = email;
    }

   

    public String getUsername() { return username; }
    public String getpassword() { return password; }
    public String getcontact() { return contact; }
    public String getaddress() { return address; }
    public String getemail() { return email; }

   
}